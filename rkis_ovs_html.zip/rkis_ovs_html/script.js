function openModal(id) {
    const modal = document.getElementById(id);
    if (modal) {
        modal.style.display = 'flex';
    } else {
        console.warn('Окно с id "' + id + '" не найдено на странице');
    }
}

function closeModal(modal) {
    if (modal) {
        modal.style.display = 'none';
    }
}

document.addEventListener('click', function (event) {
    const target = event.target;

    // кнопка, которая открывает окно: <button data-modal="id окна">
    const opener = target.closest('[data-modal]');
    if (opener) {
        openModal(opener.dataset.modal);
        return;
    }

    // index: клик по фото книги
    if (target.closest('.photo')) {
        openModal('bookModal');
        return;
    }

    // admin: клик по блоку книги
    if (target.closest('.book-adm')) {
        openModal('adminBookModal');
        return;
    }

    // крестик или кнопка «Отмена»
    if (target.closest('.modal-close, .close-modal')) {
        closeModal(target.closest('.modal'));
        return;
    }

    // клик по тёмному фону
    if (target.classList.contains('modal')) {
        closeModal(target);
    }
});

document.addEventListener('keydown', function (event) {
    if (event.key === 'Escape') {
        document.querySelectorAll('.modal').forEach(closeModal);
    }
});